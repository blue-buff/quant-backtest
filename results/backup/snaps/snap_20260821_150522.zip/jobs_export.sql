BEGIN TRANSACTION;
CREATE TABLE jobs(
 job_id INTEGER PRIMARY KEY AUTOINCREMENT,
 batch_id TEXT NOT NULL,
 exp_id TEXT NOT NULL,
 spec_path TEXT NOT NULL,
 spec_hash TEXT NOT NULL,
 runner TEXT DEFAULT 'local',
 status TEXT DEFAULT 'queued',
 attempts INTEGER DEFAULT 0,
 timeout_min INTEGER DEFAULT 60,
 created_at TEXT, started_at TEXT, finished_at TEXT,
 mlflow_run_id TEXT, error TEXT, note TEXT);
INSERT INTO "jobs" VALUES(1,'b-smoke-001','smoke_001','experiments/specs/smoke_001.json','1c7202b249323cd3','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:51','2026-08-21 15:03:54','a7cfe05a669d4efab0a9beea618aebb9',NULL,NULL);
INSERT INTO "jobs" VALUES(2,'b-smoke-001','legacy_e03_off_10d_hs300','experiments/specs/legacy_e03_10d_hs300.json','f3b73139e4a9e145','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:54','2026-08-21 15:03:58','4b491235cc1444c0af1a70eb8806f705',NULL,NULL);
INSERT INTO "jobs" VALUES(3,'b-smoke-001','eval_all10d_ens3_all','experiments/specs/eval_ens3.json','076832eb309eb3c0','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:58','2026-08-21 15:04:02','216f347d675c4f3c82cf15dc89c1c60a',NULL,NULL);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('jobs',3);
COMMIT;
