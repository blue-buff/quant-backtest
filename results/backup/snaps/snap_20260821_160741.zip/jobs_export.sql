BEGIN TRANSACTION;
CREATE TABLE events(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 job_id INTEGER, batch_id TEXT, exp_id TEXT, status TEXT, error TEXT, ts TEXT);
INSERT INTO "events" VALUES(1,4,'b-fault-001','fail_001','queued',NULL,'2026-08-21 15:43:45');
INSERT INTO "events" VALUES(2,5,'b-fault-001','hang_001','queued',NULL,'2026-08-21 15:43:45');
INSERT INTO "events" VALUES(3,4,'b-fault-001','fail_001','running',NULL,'2026-08-21 15:43:45');
INSERT INTO "events" VALUES(4,4,'b-fault-001','fail_001','failed','frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
','2026-08-21 15:43:48');
INSERT INTO "events" VALUES(5,5,'b-fault-001','hang_001','running',NULL,'2026-08-21 15:43:48');
INSERT INTO "events" VALUES(6,5,'b-fault-001','hang_001','failed','timeout (killed process group)','2026-08-21 15:43:51');
INSERT INTO "events" VALUES(7,6,'b-fault-001','fail_001','queued',NULL,'2026-08-21 15:44:46');
INSERT INTO "events" VALUES(8,7,'b-fault-001','hang_001','queued',NULL,'2026-08-21 15:44:46');
INSERT INTO "events" VALUES(9,6,'b-fault-001','fail_001','running',NULL,'2026-08-21 15:44:46');
INSERT INTO "events" VALUES(10,6,'b-fault-001','fail_001','failed','frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
','2026-08-21 15:44:48');
INSERT INTO "events" VALUES(11,7,'b-fault-001','hang_001','running',NULL,'2026-08-21 15:44:49');
INSERT INTO "events" VALUES(12,7,'b-fault-001','hang_001','failed','auto-healed: dispatcher heartbeat stale','2026-08-21 15:45:05');
INSERT INTO "events" VALUES(13,8,'b-fault-001','fail_001','queued',NULL,'2026-08-21 15:49:57');
INSERT INTO "events" VALUES(14,9,'b-fault-001','hang_001','queued',NULL,'2026-08-21 15:49:57');
INSERT INTO "events" VALUES(15,8,'b-fault-001','fail_001','running',NULL,'2026-08-21 15:49:58');
INSERT INTO "events" VALUES(16,8,'b-fault-001','fail_001','failed','frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
','2026-08-21 15:50:00');
INSERT INTO "events" VALUES(17,9,'b-fault-001','hang_001','running',NULL,'2026-08-21 15:50:00');
INSERT INTO "events" VALUES(18,9,'b-fault-001','hang_001','failed','timeout (killed process group)','2026-08-21 15:50:03');
INSERT INTO "events" VALUES(19,10,'b-server-smoke-001','smoke_002','queued',NULL,'2026-08-21 16:04:02');
INSERT INTO "events" VALUES(20,10,'b-server-smoke-001','smoke_002','running',NULL,'2026-08-21 16:04:02');
INSERT INTO "events" VALUES(21,10,'b-server-smoke-001','smoke_002','done',NULL,'2026-08-21 16:04:31');
INSERT INTO "events" VALUES(22,11,'b-dedupe-001','eval_ens3b_dupcheck','queued',NULL,'2026-08-21 16:04:55');
INSERT INTO "events" VALUES(23,11,'b-dedupe-001','eval_ens3b_dupcheck','running',NULL,'2026-08-21 16:04:55');
INSERT INTO "events" VALUES(24,11,'b-dedupe-001','eval_ens3b_dupcheck','done',NULL,'2026-08-21 16:04:59');
INSERT INTO "events" VALUES(25,12,'b-dedupe-002','eval_ens3c_dupcheck','queued',NULL,'2026-08-21 16:05:14');
INSERT INTO "events" VALUES(26,12,'b-dedupe-002','eval_ens3c_dupcheck','running',NULL,'2026-08-21 16:05:14');
INSERT INTO "events" VALUES(27,12,'b-dedupe-002','eval_ens3c_dupcheck','done',NULL,'2026-08-21 16:05:17');
CREATE TABLE jobs(
 job_id INTEGER PRIMARY KEY AUTOINCREMENT,
 batch_id TEXT NOT NULL,
 exp_id TEXT NOT NULL,
 spec_path TEXT NOT NULL,
 spec_hash TEXT NOT NULL,
 runner TEXT DEFAULT 'local',
 status TEXT DEFAULT 'queued',
 attempts INTEGER DEFAULT 0,
 timeout_min INTEGER DEFAULT 60,
 created_at TEXT, started_at TEXT, finished_at TEXT,
 mlflow_run_id TEXT, error TEXT, note TEXT);
INSERT INTO "jobs" VALUES(1,'b-smoke-001','smoke_001','experiments/specs/smoke_001.json','1c7202b249323cd3','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:51','2026-08-21 15:03:54','a7cfe05a669d4efab0a9beea618aebb9',NULL,NULL);
INSERT INTO "jobs" VALUES(2,'b-smoke-001','legacy_e03_off_10d_hs300','experiments/specs/legacy_e03_10d_hs300.json','f3b73139e4a9e145','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:54','2026-08-21 15:03:58','4b491235cc1444c0af1a70eb8806f705',NULL,NULL);
INSERT INTO "jobs" VALUES(3,'b-smoke-001','eval_all10d_ens3_all','experiments/specs/eval_ens3.json','076832eb309eb3c0','local','done',1,5,'2026-08-21 15:03:51','2026-08-21 15:03:58','2026-08-21 15:04:02','216f347d675c4f3c82cf15dc89c1c60a',NULL,NULL);
INSERT INTO "jobs" VALUES(4,'b-fault-001','fail_001','experiments/specs/fail_001.json','b00d12635cc8a10f','local','failed',1,5,'2026-08-21 15:43:45','2026-08-21 15:43:45','2026-08-21 15:43:48',NULL,'frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
',NULL);
INSERT INTO "jobs" VALUES(5,'b-fault-001','hang_001','experiments/specs/hang_001.json','0dc38d7dbb460960','local','failed',1,5,'2026-08-21 15:43:45','2026-08-21 15:43:48','2026-08-21 15:43:51',NULL,'timeout (killed process group)',NULL);
INSERT INTO "jobs" VALUES(6,'b-fault-001','fail_001','experiments/specs/fail_001.json','b00d12635cc8a10f','local','failed',1,5,'2026-08-21 15:44:46','2026-08-21 15:44:46','2026-08-21 15:44:48',NULL,'frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
',NULL);
INSERT INTO "jobs" VALUES(7,'b-fault-001','hang_001','experiments/specs/hang_001.json','0dc38d7dbb460960','local','failed',1,5,'2026-08-21 15:44:46','2026-08-21 15:44:49','2026-08-21 15:45:05',NULL,'dispatcher died (heartbeat stale), auto-healed',NULL);
INSERT INTO "jobs" VALUES(8,'b-fault-001','fail_001','experiments/specs/fail_001.json','b00d12635cc8a10f','local','failed',1,5,'2026-08-21 15:49:57','2026-08-21 15:49:58','2026-08-21 15:50:00',NULL,'frozen runpy>", line 88, in _run_code
  File "/root/quant/pipeline/harness.py", line 149, in <module>
    main()
  File "/root/quant/pipeline/harness.py", line 144, in main
    run(a.spec_path, a.job_id, a.batch_id)
  File "/root/quant/pipeline/harness.py", line 98, in run
    raise ValueError("deterministic crash for failure-path testing")
ValueError: deterministic crash for failure-path testing
',NULL);
INSERT INTO "jobs" VALUES(9,'b-fault-001','hang_001','experiments/specs/hang_001.json','0dc38d7dbb460960','local','failed',1,5,'2026-08-21 15:49:57','2026-08-21 15:50:00','2026-08-21 15:50:03',NULL,'timeout (killed process group)',NULL);
INSERT INTO "jobs" VALUES(10,'b-server-smoke-001','smoke_002','experiments/specs/smoke_002.json','8095695d5da29027','local','done',1,5,'2026-08-21 16:04:02','2026-08-21 16:04:02','2026-08-21 16:04:31','0601052cbb904ca99122f2031ba6de69',NULL,NULL);
INSERT INTO "jobs" VALUES(11,'b-dedupe-001','eval_ens3b_dupcheck','experiments/specs/eval_ens3b.json','2d8529ab859b78f8','local','done',1,5,'2026-08-21 16:04:55','2026-08-21 16:04:55','2026-08-21 16:04:59','216f347d675c4f3c82cf15dc89c1c60a',NULL,NULL);
INSERT INTO "jobs" VALUES(12,'b-dedupe-002','eval_ens3c_dupcheck','experiments/specs/eval_ens3c.json','a3915f99a2b86c09','local','done',1,5,'2026-08-21 16:05:14','2026-08-21 16:05:14','2026-08-21 16:05:17','83d5848bacaf4e5693558308cbc2792e',NULL,NULL);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('jobs',12);
INSERT INTO "sqlite_sequence" VALUES('events',27);
COMMIT;
